let button;
let img;

function preload() {
  img = loadImage('skyimage.jpg');
}

function setup() {
  createCanvas(626, 417);
  background('cyan');
  noCursor();
   button = createImg('quail.png');
  button.class('myButton');
  button.mouseOver(runAway);
  button.mouseClicked(success);
  button.size(75,75);
  
}

function draw() {
  circle(mouseX, mouseY, 10, 10);
  fill('red');
  text('Get me!', 255, 200);
  textSize(32);
  stroke(0);
  strokeWeight(4);
}

function runAway(){
  button.position(random(50,200), random(50,200));
}

function success(){
  button.hide();
}